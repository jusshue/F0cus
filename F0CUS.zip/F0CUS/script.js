const quotes = [
  "In this world, there are things you have to protect even if your hands get stained with blood.",
"People will do anything when their existence is threatened. It's only natural to survive.",
"It's not about winning or losing. It's about standing at the top.",
"Weakness is a sin.",
"There's no point in looking back. What's important is what comes next.",
"The world is full of lies.",
"Talent is something you make bloom, instinct is something you polish.",
"The only one you can trust is yourself.",
"The only limit to our realization of tomorrow is our doubts of today.",
"Success is not the key to happiness. Happiness is the key to success.",
"Knowledge is power. But power is nothing if you can't use it.",
"Life is like a game. The more skilled you become, the more interesting it gets.",
"Fear isn't evil. It tells you what your weakness is.",
"Even if you're deceived, it doesn't mean you're stupid.",
"There's no such thing as absolute fairness or absolute justice.",
"Pretending to be weak when you're strong is one of life's greatest mysteries.",
"The best and most beautiful things in the world cannot be seen or even touched - they must be felt with the heart.",
"Success consists of going from failure to failure without loss of enthusiasm.",
"The world is full of lies, but that's exactly why the truth stands out.",
"In a world where everyone lies, the only true path is the one paved with deception.",
"Even if the truth is hard to accept, it's better than living a lie.",
"You miss 100% of the shots you don't take.",
"Life is like a game of chess. To win, you have to make a move.",
"If you don't grasp the rules, you'll never win.",
"The only way to find out what you're truly capable of is to push yourself to the limit.",
"Humans are interesting creatures. The more they learn, the more they want to learn.",
"The truth is often harder to believe than a lie.",
"If you don't understand something, it doesn't mean it's not true.",
"There's no point in regretting something you couldn't have changed.",
"People are born to become tools.",
"If you can't stand on your own, you should fall.",
"The moment you start doubting someone, it's the beginning of the end.",
"You can't stand at the top if you're weak.",
"Weaklings can't choose their way of death. It's decided for them.",
"If you don't trust anyone, then at least trust in yourself.",
"The only way to rise from the bottom to the top is to be ruthless.",
"Even if you're alone, as long as you have the will to win, you're not really alone.",
"No matter what you do, it's meaningless if you don't have the resolve to see it through.",
"If you don't understand what's happening, you're already lost.",
"Believe only in yourself. That's the only truth.",
"There's no such thing as a painless lesson.",
"Pain is inevitable, but suffering is optional.",
"Don't trust in the good intentions of others. Trust only in their actions.",
"It's not about whether it's right or wrong. It's about survival.",
"Don't let your guard down, even for a moment.",
"The stronger you become, the more enemies you'll have.",
"To win, you have to be willing to sacrifice everything.",
"The world doesn't revolve around you. It revolves around power.",
"In the end, the only thing that matters is who stands at the top.",
    // Add all your quotes here
];

let timer;
let quoteIndex = 0;
let studyTime = 25; // Default study time (in minutes)
const quoteChangeInterval = 12 * 60 * 1000; // Interval for changing quotes in milliseconds

function startStudy() {
    let seconds = studyTime * 60;
    timer = setInterval(() => {
        seconds--;
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        const displayTime = `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
        document.querySelector('.timer').textContent = displayTime;

        // Change quote every 12 minutes
        if (seconds % (12 * 60) === 0) {
            changeQuote();
        }

        if (seconds === 0) {
            clearInterval(timer);
            document.querySelector('.timer').textContent = "Time's up!";
        }
    }, 1000);
}

function stopStudy() {
    clearInterval(timer);
}

function resetStudy() {
    clearInterval(timer);
    document.querySelector('.timer').textContent = "00:00";
}

function changeQuote() {
    quoteIndex = Math.floor(Math.random() * quotes.length); // Randomize quote index
    document.querySelector('.quote').textContent = quotes[quoteIndex];
}

document.getElementById('startBtn').addEventListener('click', startStudy);
document.getElementById('stopBtn').addEventListener('click', stopStudy);
document.getElementById('resetBtn').addEventListener('click', resetStudy);

// Initialize with a random quote
changeQuote();

// Listen for changes in study time
document.getElementById('concentrationTime').addEventListener('change', function() {
    studyTime = parseInt(this.value);
    const displayTime = `${studyTime.toString().padStart(2, '0')}:00`;
    document.querySelector('.timer').textContent = displayTime;
});
